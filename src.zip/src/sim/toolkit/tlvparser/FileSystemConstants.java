/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sim.toolkit.tlvparser;

/**
 *
 * @author user
 */
public interface FileSystemConstants {
    public static final String DF_MF = "3F00";
    public static final String DF_GSM = "7F20";
    public static final String DF_TELECOM = "7F10";
    public static final String EF_IMSI = "6F07";
    public static final String EF_DIR = "2F00";
    
}
