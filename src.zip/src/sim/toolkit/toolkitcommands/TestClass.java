/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sim.toolkit.toolkitcommands;

/**
 *
 * @author user
 */
public class TestClass {
    public static void main(String args[])
    {
        System.out.println("You are under the test class");
        Refresh pi = Refresh.getInstance();
        pi.parseCommand("D081A18103010101820281828402011E0D819141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141");
    }
}
